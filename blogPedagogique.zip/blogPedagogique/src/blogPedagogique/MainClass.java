package blogPedagogique;

import javax.swing.UIManager;
import javax.swing.plaf.nimbus.NimbusLookAndFeel;

public class MainClass {
	 public static void main(String[] args) throws Exception {
			UIManager.setLookAndFeel(new NimbusLookAndFeel());
			
			new Fenetre();
		}
}
