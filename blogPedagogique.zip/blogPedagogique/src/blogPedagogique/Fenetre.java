package blogPedagogique;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.text.MaskFormatter;


public class Fenetre extends JFrame{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private JPanel acl=new JPanel() {
		 /**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		public void paintComponent(Graphics g){
			 
			  //Image de font
			   try {
			      Image img = ImageIO.read(new File("1.jpg"));
			      g.drawImage(img, 0, 0, this.getWidth(), this.getHeight(), this);
			    } catch (IOException e) {
			      e.printStackTrace();
			    } 
		  }
	};
	
	
		
	private JPanel cnx=new JPanel() {
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		public void paintComponent(Graphics g) {
			 Graphics2D g2d = (Graphics2D)g;       
			 Color couleur1 = new Color(209,107,165);
			 Color couleur2 = new Color(82,207,254);
			 
			    GradientPaint gp = new GradientPaint(0, 0, couleur1, 80, -120, couleur2);                
			    g2d.setPaint(gp);
			    g2d.fillRect(0, 0, this.getWidth(), this.getHeight()); 
			    
			    //rectangle 
			    Color couleur = new Color(255,255,255,200);
			    g.setColor(couleur);
			    g.fillRect(50, 25, this.getWidth()-100, this.getHeight()-50);
				}
	};
	
	private JPanel inscr=new JPanel() {
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		public void paintComponent(Graphics g) {
			Graphics2D g2d = (Graphics2D)g;       
			 Color couleur1 = new Color(209,107,165);
			 Color couleur2 = new Color(82,207,254);
			 
			    GradientPaint gp = new GradientPaint(0, 0, couleur1, 80, -120, couleur2);                
			    g2d.setPaint(gp);
			    g2d.fillRect(0, 0, this.getWidth(), this.getHeight()); 
			    
			    //rectangle 
			    Color couleur = new Color(255,255,255,200);
			    g.setColor(couleur);
			    g.fillRect(50, 25, this.getWidth()-100, this.getHeight()-50);
			   }
	};

	
	
	private JPanel ihma=new JPanel() {
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		public void paintComponent(Graphics g){
		    Graphics2D g2d = (Graphics2D)g;       
		    Color couleur1 = new Color(209,107,165);
		    Color couleur2 = new Color(82,207,254);
		    GradientPaint gp = new GradientPaint(0, 0, couleur1, 60, -180, couleur2);                
		    g2d.setPaint(gp);
		    g2d.fillRect(0, 0, this.getWidth(), 100); 
	}
	};

	private String ens_OU_etu;  
	private String nom = "";
	private JPanel pIHM1=new JPanel(), pIHM2=new JPanel(), pIHM3=new JPanel(); 
	private JPanel panComm = new JPanel();
	private int posFichierTP = 5;
	private int posFichierC = 5;
	private int posFichierE = 5;
	private int posComm = 5;
	private JPanel panTxtA = new JPanel();
	private JPanel ajouPan = new JPanel();
	private String nomF="";
	private JPanel panP=new JPanel();
	private JScrollPane scrollPane = new JScrollPane(ihma, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
	private FileInputStream input;


	//--------------------------------------------------------------------------------------------------------------------------------------------------------------------
	Fenetre(){
		
		//cr�ation de la fen�tre
		this.setTitle("Blog P�dagogique");	 
		this.setSize(600, 500);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		this.setIconImage(new ImageIcon("icon.png").getImage()); 
		this.setBackground(Color.white);
	    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    this.setVisible(true);
		
		
		//---------------------------------------------panel de page d acceuil----------------------------------------------------------//
		acl.setLayout(null);
		this.setContentPane(acl);
		
		 //Titre
		JLabel labTAcl1= label("Cours,Tp et Examens",255,50,400,100,Color.white,28);
		acl.add(labTAcl1);
		JLabel labTAcl2= label("pour module Interface ",245,100,400,100,Color.white,28);
		acl.add(labTAcl2);
		JLabel labTAcl3= label("Homme Machine",290,150,400,100,Color.white,28);
		acl.add(labTAcl3);
		
		
		//boutons              
		JButton btnInscr= bouton("inscrirez-vous",400, 280, 125, 35,null,Color.white);
		acl.add(btnInscr);
		btnInscr.addActionListener(new ActionListener(){
	        public void actionPerformed(ActionEvent clic) {
	        	acl.setVisible(false);
	        	Fenetre.this.setContentPane(inscr);
	        	inscr.setVisible(true);
	        } });
		
		JLabel labTAcl4= label("OU",445,310,100,50,Color.white,23);
		acl.add(labTAcl4);
		
		JButton btnCnx= bouton("connectez-vous",400, 360, 125, 35,null,Color.white);
		acl.add(btnCnx);
		btnCnx.addActionListener(new ActionListener(){
	        public void actionPerformed(ActionEvent clic) {
	        	acl.setVisible(false);
	        	Fenetre.this.setContentPane(cnx);
	        	cnx.setVisible(true);
	        } });
		 
		Icon icn = new ImageIcon("btn.png");
	    JButton btnInter = new JButton(icn);
	    btnInter.setBounds(540, 420, 40, 40);
	    btnInter.setBorderPainted(false);
	    acl.add(btnInter);
	    btnInter.addActionListener(new ActionListener(){
	        public void actionPerformed(ActionEvent arg0) {
		    	JOptionPane.showMessageDialog(null, "Blog P�dagogique\r\n" + 
		    			"     version 1.0\r\n" + 
		    			"     2019-2020\r\n" + 
		    			"     par:\r\n" + 
		    			"	       BRAIKIA Houria\n" + 
		    			"       HALOUI Sarra\r	", "  � propos", JOptionPane.INFORMATION_MESSAGE,new ImageIcon(new ImageIcon("icon.png").getImage().getScaledInstance(70, 70, Image.SCALE_DEFAULT)));}
	      });
	//---------------------------------------------------------------- Connexion--------------------------------------------------------------------//
	    cnx.setLayout(null); 
	    
	    //titre
	    JLabel labTCnx= label("Connectez-vous",200,50,400,100,Color.black,25);
	    cnx.add(labTCnx);
	    JLabel logo = new JLabel(new ImageIcon(new ImageIcon("book.gif").getImage().getScaledInstance(250, 200, Image.SCALE_DEFAULT)));
		logo.setBounds(50, 150, 250, 200);
		cnx.add(logo);
	   
	    //champ du formulaire
	    JLabel labNom= label("Nom d'utilisateur*", 330,125,200,50,Color.black,15);
	    cnx.add(labNom);
		
	   MaskFormatter form = null;
		try {
			form = new MaskFormatter("?AAAAAAA");
		} catch (ParseException e) {  e.printStackTrace(); }
		
		JFormattedTextField jtf_nom = new JFormattedTextField(form);
		((JFormattedTextField) jtf_nom).setFocusLostBehavior( JFormattedTextField.PERSIST );//Cela permet de garder ce que je saisis dans la zone de texte m�me si le nombre maxi de caract�res n'est pas atteint.
		jtf_nom.setSize(120,30);
		jtf_nom.setLocation(330, 175);
		cnx.add(jtf_nom);
		
		JButton labTCnxIndiq1 = new JButton(new ImageIcon("info.png"));
		labTCnxIndiq1.setBounds(455, 175, 25, 25);
		labTCnxIndiq1.setBorderPainted(false);
		labTCnxIndiq1.setContentAreaFilled(false);
		cnx.add(labTCnxIndiq1);
		labTCnxIndiq1.addActionListener(new ActionListener(){
	        public void actionPerformed(ActionEvent arg0) {
		    	JOptionPane.showMessageDialog(null,"La valeur doit �tre unique et: \r\n" + 
		    			"	alphanum�rique,\r\n" + 
		    			"	ne commence pas par un chiffre,\r\n" + 
		    			"	ne d�passe pas 10 caract�res.","Concernant le nom d'utilisateur", JOptionPane.INFORMATION_MESSAGE);}
	      });
		
		JLabel labMP =label("Mot de passe*",  330,205,200,50,Color.black,15);
	    cnx.add(labMP);
	    
		JPasswordField jtf_mp = new JPasswordField(10);
		jtf_mp.setSize(120, 30);
		jtf_mp.setLocation(330, 255);
		cnx.add(jtf_mp);
		
	    
	    JButton labTCnxIndiq2 = new JButton(new ImageIcon("info.png"));
	    labTCnxIndiq2.setBounds(455, 255, 25, 25);
	    labTCnxIndiq2.setBorderPainted(false);
	    labTCnxIndiq2.setContentAreaFilled(false);
	    cnx.add(labTCnxIndiq2);
		labTCnxIndiq2.addActionListener(new ActionListener(){
	        public void actionPerformed(ActionEvent arg0) {
		    	JOptionPane.showMessageDialog(null,"La valeur ne doit pas d�passer 10 caract�res","Concernant le mot de passe", JOptionPane.INFORMATION_MESSAGE);}
	      });
		
		//etudiant ou enseignat
				JPanel pan=new JPanel();
				pan.setBounds(330, 310,160,30);
				pan.setBackground(new Color(255,255,255,255));
			    ButtonGroup bg = new ButtonGroup();
			    JRadioButton etu = new JRadioButton("Etudiant");
			    etu.setLocation(330, 310);
			    JRadioButton ens = new JRadioButton("Enseignat");
			    ens.setLocation(360, 310);
			    bg.add(ens);
			    bg.add(etu);
			    pan.add(ens);
			    pan.add(etu);
			    cnx.add(pan);

				etu.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						if(((JRadioButton) e.getSource()).isSelected()) 
							ens_OU_etu = "etudiant";
					}
				});
				
				ens.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						if(((JRadioButton) e.getSource()).isSelected()) 
							ens_OU_etu = "enseignant";
					}	
				});
		
    
		JButton btnCon = bouton("Connexion",380,360, 110, 35,null,Color.white);
		cnx.add(btnCon);
		
		btnCon.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent clic) {
				String nm = jtf_nom.getText();
				@SuppressWarnings("deprecation")
				String mp = jtf_mp.getText();
				int resultat = 0;
		        if(mp.isEmpty()||nm.equals("        ")) 
		        	{JOptionPane.showMessageDialog(null, " Vous avez oubli� d'entrer un nom d'utilisateur ou un mot de passe ","Error Message", JOptionPane.ERROR_MESSAGE);}
		        else {
		        	if(ens_OU_etu.equals("")) 
		        		JOptionPane.showMessageDialog(null, " Enseignant ou �tudient ? ","Error Message", JOptionPane.ERROR_MESSAGE);
		        	else {	resultat = connexionSQLSelect(nm,mp);
		        			if(resultat==0) 
		        				JOptionPane.showMessageDialog(null, " Nom d'utilisateur ou mot de passe incorrect! ","Error Message", JOptionPane.ERROR_MESSAGE);
		        			else {
		        				nom = nm;
		        				
		           				cnx.setVisible(false);
		        				Fenetre.this.setContentPane(scrollPane);
		        				scrollPane.setVisible(true);
		        				}
		        		}
		        	}
        } });
    
		
		//----------------------------------------------------------Inscription---------------------------------------------------------------------//
	    inscr.setLayout(null);
	    
	    JLabel labTtr =label("Inscrivez-vous",200,50,400,100,Color.black,25);
	    inscr.add(labTtr);
	    JLabel logo1 = new JLabel(new ImageIcon(new ImageIcon("book.gif").getImage().getScaledInstance(250, 200, Image.SCALE_DEFAULT)));
	    logo1.setBounds(50, 150, 250, 200);
		inscr.add(logo1);
	    
	    JLabel labN= label("Nom d'utilisateur*", 330,125,200,50,Color.black,15);
	    inscr.add(labN);
	    
	    JFormattedTextField jtf_nom2 = new JFormattedTextField(form);
		((JFormattedTextField) jtf_nom2).setFocusLostBehavior( JFormattedTextField.PERSIST );//Cela permet de garder ce que je saisis dans la zone de texte m�me si le nombre maxi de caract�res n'est pas atteint.
		jtf_nom2.setSize(120,30);
		jtf_nom2.setLocation(330, 175);
		jtf_nom2.setValue("");
	    inscr.add(jtf_nom2);
	    
	    JButton labTinscrIndiq1 = new JButton(new ImageIcon("info.png"));
	    labTinscrIndiq1.setBounds(455, 175,25, 25);
	    labTinscrIndiq1.setContentAreaFilled(false);
	    labTinscrIndiq1.setBorderPainted(false);
	    inscr.add(labTinscrIndiq1);
		labTinscrIndiq1.addActionListener(new ActionListener(){
	        public void actionPerformed(ActionEvent arg0) {
		    	JOptionPane.showMessageDialog(null,"La valeur doit �tre unique et: \r\n" + 
		    			"	alphanum�rique,\r\n" + 
		    			"	ne commence pas par un chiffre,\r\n" + 
		    			"	ne d�passe pas 10 caract�res.","Concernant le nom d'utilisateur", JOptionPane.INFORMATION_MESSAGE);}
	      });
		
	    JLabel labMp =label("Mot de passe*", 330,205,200,50,Color.black,15);
	    inscr.add(labMp);
	    
		JPasswordField jtf_mp2 = new JPasswordField();
		jtf_mp2.setSize(120, 30);
		jtf_mp2.setLocation(330, 255);
		inscr.add(jtf_mp2);
		
		JButton labTinscrIndiq2 = new JButton(new ImageIcon("info.png"));
		labTinscrIndiq2.setBounds(455, 255, 25, 25);
		labTinscrIndiq2.setBorderPainted(false);	
		labTinscrIndiq2.setContentAreaFilled(false);
		inscr.add(labTinscrIndiq2);
		labTinscrIndiq2.addActionListener(new ActionListener(){
	        public void actionPerformed(ActionEvent arg0) {
		    	JOptionPane.showMessageDialog(null,"La valeur ne doit pas d�passer 10 caract�res","Concernant le mot de passe", JOptionPane.INFORMATION_MESSAGE);}
	      });
		
		//etudiant ou enseignant
		JPanel pan1=new JPanel();
		pan1.setBounds(330, 310,160,30);
		pan1.setBackground(new Color(255,255,255,255));
	    ButtonGroup bg1 = new ButtonGroup();
	    JRadioButton etu1 = new JRadioButton("Etudiant");
	    JRadioButton ens1 = new JRadioButton("Enseignat");
	    bg1.add(ens1);
	    bg1.add(etu1);
	    pan1.add(ens1);
	    pan1.add(etu1);
		inscr.add(pan1);
		
		etu1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(((JRadioButton) e.getSource()).isSelected()) {
					ens_OU_etu = "etudiant";
				}
			}
			
		});
		
		ens1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(((JRadioButton) e.getSource()).isSelected()) {
					ens_OU_etu = "enseignant";
				}
			}
			
		});

	    
		JButton btnIn = bouton("Inscription",380,360,110,35,null,Color.white);
		inscr.add(btnIn);

		btnIn.addActionListener(new ActionListener(){
	    public void actionPerformed(ActionEvent clic) {

	        @SuppressWarnings("deprecation")
			String mp = jtf_mp2.getText();
	        String nm = jtf_nom2.getText();
	        
	        if(mp.isEmpty()||nm.equals("        ")) 
	        	{JOptionPane.showMessageDialog(null, " Vous avez oubli� d'entrer un nom d'utilisateur ou un mot de passe ","Error Message", JOptionPane.ERROR_MESSAGE);}
	        else {
	        	if(ens_OU_etu.equals("")) 
	        		{JOptionPane.showMessageDialog(null, " Enseignant ou �tudient ? ","Error Message", JOptionPane.ERROR_MESSAGE);}
	        	else if(connexionSQLSelect(nm,mp)==1) 
	        	{JOptionPane.showMessageDialog(null, " Ce nom existe d�j� !","Error Message", JOptionPane.ERROR_MESSAGE);}
	        	else {
	        		if(ens_OU_etu=="enseignant") 
	        			connexionSQLInsert("insert into enseignant (nom,motDePasse) values ('"+nm+"','"+mp+"');");
	        		else 
	        			connexionSQLInsert("insert into etudient (nom,motDePasse) values ('"+nm+"','"+mp+"');");
	        			nom = nm;
	        			
	        			inscr.setVisible(false);
	        			Fenetre.this.setContentPane(scrollPane);
	        			scrollPane.setVisible(true);
	        	}
	        }
	        
	         } });
	  
	   

		//------------------------------------IHM---------------------------------------//
		panP.add(scrollPane);//j ai creer un panP qui add JScrollPane contient ihma 
		
		ihma.setLayout(null);
	    ihma.setPreferredSize(new Dimension(590, 800));   
	    
		scrollPane.add(ihma);
		scrollPane.setViewportView(ihma);
		 
		
	    //titre
	    JLabel labTIHM= label("Interface Homme Machine", 140,20,400,50,Color.white,28);
	    ihma.add(labTIHM);
	    
	    //bouton de quitter
	    JButton btnQuitter = bouton("", 520, 760,40,40,new ImageIcon("quitter.png"),Color.white);
        btnQuitter.setBorderPainted(false);
        btnQuitter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
						int n = JOptionPane.showConfirmDialog(null, "voulez-vous quitter?"); 
						if(n==0)  {
							Fenetre.this.dispose();;
						}		
			}
        });
		ihma.add(btnQuitter);
	    
	    //menu
	    chargerTP();
	    chargerCours();
	    chargerExm();
	    chargerCmm();
		
	    pIHM1.setLayout(null);
	    pIHM2.setLayout(null);
	    pIHM3.setLayout(null);
	    

		JTabbedPane menuIHM = new JTabbedPane();
		menuIHM.setBounds(0,80,600,180); 
		
		menuIHM.add("COURS",pIHM1);  
		menuIHM.add("TP",pIHM2); 
		menuIHM.add("EXAMENS",pIHM3);
		ihma.add(menuIHM);
			
			
		
		//ajouter fichier
		ajouPan.setLayout(null);
		ajouPan.setBounds(0, 260, 600, 600);
		ajouPan.setBackground(Color.white);
		ihma.add(ajouPan);
		
		JLabel ajouPDF = label ("Ajouter Des Fichiers",(this.getWidth()/2)-100,5,300,50,new Color(0,18,55),20);
		ajouPan.add(ajouPDF);
		
		Color c = new Color(157,205,254,255);
		Icon icnAjTP = new ImageIcon(new ImageIcon("TP.png").getImage().getScaledInstance(40,40, Image.SCALE_DEFAULT));
		JButton bntAjTP = bouton("TP",55,60,130,90,icnAjTP,c);
		bntAjTP.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					ajouterFichier(bntAjTP.getText());
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				}
			}
			
		});
		ajouPan.add(bntAjTP);	
		Icon icnAjCr = new ImageIcon(new ImageIcon("cours.png").getImage().getScaledInstance(40,40, Image.SCALE_DEFAULT));
		JButton bntAjCr = bouton("Cours",230,60,130,90,icnAjCr,c);
		bntAjCr.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					ajouterFichier(bntAjCr.getText());
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				}
			}
			
		});
		ajouPan.add(bntAjCr);
		Icon icnAjEx = new ImageIcon(new ImageIcon("exm.png").getImage().getScaledInstance(40,40, Image.SCALE_DEFAULT));
		JButton bntAjEx = bouton("Examen",410,60,130,90,icnAjEx,c);
		bntAjEx.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					ajouterFichier(bntAjEx.getText());
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				}
			}
			
		});
		ajouPan.add(bntAjEx);
		
		JLabel commLab= label ("Commentaire",30,160,300,50,new Color(0,18,55),20);
		ajouPan.add(commLab);
		
		
		//commentaire 
		
		panTxtA.setBackground(Color.white);
		panTxtA.setBounds(0,200, 595, 300);
		panTxtA.setLayout(null);
		panTxtA.setBackground(new Color(173,216,230));
		panTxtA.setBorder(BorderFactory.createLineBorder(new Color(0,18,55)));
		ajouPan.add(panTxtA);
		
		panComm.setBackground(Color.white);
		panComm.setBounds(0,75, 595, 225);
		panComm.setLayout(null);
		panComm.setBorder(BorderFactory.createLineBorder(new Color(0,18,55))); 
		
		panTxtA.add(panComm);
		
		JLabel commlogo = new JLabel(new ImageIcon(new ImageIcon("profil.png").getImage().getScaledInstance(60, 60, Image.SCALE_DEFAULT)));
		commlogo.setBounds(10, 5, 60, 60);
		panTxtA.add(commlogo);
		
		JTextArea txtA = new JTextArea("Ajouter un commentaire ");
		txtA.setBounds(90,10,350,60);
		txtA.setMaximumSize(new Dimension(250,70));
		txtA.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(new Color(0,18,55)),null, 0, 0,null, new Color(0,18,55)));
		txtA.setFont(new Font("Comic sans MS", 13, 13));
		panTxtA.add(txtA);
		
		JButton ajouComBtn = bouton("Ajouter", 460, 10,90,30,null,Color.white);
		panTxtA.add(ajouComBtn);
		ajouComBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String txt = txtA.getText();
				if(txt.isEmpty()||txt.equals("Ajouter un commentaire "))
		     		{JOptionPane.showMessageDialog(null, " Vous n'avez pas entr� un commentaire","Error Message", JOptionPane.ERROR_MESSAGE);}
				else 
					ajouterComm(txt);
			}
		});

       /* JScrollPane scrollPane1 = new JScrollPane();
		scrollPane.setBounds(180, 110, 430, 350);
		scrollPane1.setViewportView(panComm);
		ihma.add(scrollPane1);*/
		        
				
		        
		        
		        
		}
		
		
//------------------------------------fct--------------------------------------------------------------------------------------------------------------------------------
	public JLabel label(String str,int x,int y,int langeur, int longueur,Color couleur,int size) {
		Font font = new Font("Comic sans MS", Font.BOLD, size);
		JLabel lab= new JLabel(str);
		lab.setFont(font);
		lab.setForeground(couleur);
		lab.setBounds(x,y,langeur,longueur);
		return lab;
	}
	 
	public JButton boutonIcon(Icon icn, int posX, int posY, int largeur, int longueur) {
		JButton btn = new JButton(icn);
	    btn.setBounds(posX,posY,largeur, longueur);
	    btn.setBorderPainted(false);
	    btn.setBackground(Color.white);
		return btn;
	}
	
	 public JButton bouton(String titre, int posX, int posY, int largeur, int longueur,Icon icn,Color couleur) {
			JButton btn = new JButton(titre,icn);
			btn.setBounds(posX, posY, largeur, longueur);
			//btn.setBorderPainted(false);
			btn.setBackground(couleur);
		    Font font = new Font("Comic sans MS", Font.BOLD, 13);
			btn.setFont(font);
			return btn;
		}
	 
	 public void connexionSQLInsert(String query) {
		//connexion a la base de donnee	
			Connection connect=null; // connexion avec la base
			Statement stm=null; // permet l exe des instr SQL
			
			try{
				//charger le pilote
				 Class.forName("com.mysql.cj.jdbc.Driver");
				 connect=DriverManager.getConnection("jdbc:mysql://localhost:3306/tpihm","root","");
				 stm=connect.createStatement();
				 stm.executeUpdate(query);
				 } catch (Exception e){System.out.println(e); }
			
			// fermeture de la base
			finally {
			        if (stm != null) try { stm.close(); } catch (SQLException ignore) {}
			        if (connect != null) try { connect.close(); } catch (SQLException ignore) {}
			    }
	 }
	
	 public int connexionSQLSelect(String nm , String mp) {
			//connexion a la base de donnee	
				Connection connect = null; // connexion avec la base
				PreparedStatement stm=null; // objet d'�mission des requ�tes
				ResultSet resultat = null;
				int res = 0;
				try{
					//charger le pilote
					 Class.forName("com.mysql.cj.jdbc.Driver");
					 connect=DriverManager.getConnection("jdbc:mysql://localhost:3306/tpihm","root","");
					 
					 if(ens_OU_etu=="enseignant") { 
						stm=connect.prepareStatement("select * from enseignant where nom = ?;");
						stm.setString(1,nm);
						resultat= stm.executeQuery();
						while(resultat.next()) {
							String y = resultat.getString("nom").toString();
							String z = resultat.getString("motDePasse").toString();
							if(y.equals(nm) && z.equals(mp))
								res = 1;	
							}
					 }
					 else if(ens_OU_etu=="etudiant"){ 
						 stm=connect.prepareStatement("select * from etudient where nom = ?;");
							stm.setString(1,nm);
							resultat= stm.executeQuery();
							while(resultat.next()) {
								String y = resultat.getString("nom").toString();
								String z = resultat.getString("motDePasse").toString();
								if(y.equals(nm) && z.equals(mp))
									res = 1;	
								}
					 }
					 } catch (Exception e){System.out.println(e);} 
				
				// fermeture de la base
					finally {
					        if (resultat != null) try { resultat.close(); } catch (SQLException ignore) {}
					        if (stm != null) try { stm.close(); } catch (SQLException ignore) {}
					        if (connect != null) try { connect.close(); } catch (SQLException ignore) {}
					    }
				return res;
				}
	 
	
	 
	 public void ajouterFichier(String tbl) throws FileNotFoundException {
		 JFileChooser file_chooser = new JFileChooser("C:\\Users\\pcstar\\Desktop");
		 FileNameExtensionFilter filter = new FileNameExtensionFilter("", "pdf");
		 file_chooser.addChoosableFileFilter(filter);
		// if the user selects a file
			if(file_chooser.showOpenDialog(null)==JFileChooser.APPROVE_OPTION){
	            // set the label to the path of the selected file
				File file = new File(file_chooser.getSelectedFile().getAbsolutePath());
				input = new FileInputStream(file);
			     nomF =file_chooser.getSelectedFile().getName() ;
			     
			   connexionSQLInsert("insert into "+tbl+"(nom,Fichier,nomFichier) values('"+nom+"','"+input+"','"+nomF+"');");
			  
			   if(tbl=="Cours") {
				   JButton btnTel= bouton("Ouvrir",400,posFichierC,120,30,null,Color.white);
				   pIHM1.add(btnTel);
				   
				   btnTel.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent arg0) {
							File file = new File("C:\\Users\\pcstar\\Desktop\\fichier\\"+nomF);
				              Desktop desktop = Desktop.getDesktop();
				        try {
				            desktop.open(file);
				        } catch (IOException ex) { }
						}});
				   
				   JLabel lab = new JLabel();
				   lab.setText(nomF +" ajout� par "+nom);
				   lab.setBounds(25, posFichierC, 325, 30);
				   pIHM1.add(lab);
					
				   posFichierC+=50;
			   }
				   
			   else if(tbl=="TP") {
				   JLabel lab = new JLabel();
				   lab.setText(nomF +" ajout� par "+nom);
				   lab.setBounds(25, posFichierTP, 325, 30);
				   pIHM2.add(lab);
				   JButton btnTel = bouton("Ouvrir",400,posFichierTP,120,30,null,Color.white);
				   btnTel.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent arg0) {
							File file = new File("C:\\Users\\pcstar\\Desktop\\fichier\\"+nomF);
				              Desktop desktop = Desktop.getDesktop();
				        try {
				            desktop.open(file);
				        } catch (IOException ex) { }
						}});
				   pIHM2.add(btnTel);
				   
				   posFichierTP+=50;
			   }
			   else{
				   JLabel lab = new JLabel();
				   lab.setText(nomF +" ajout� par "+nom);
				   lab.setBounds(25, posFichierE, 325, 30);
				   pIHM3.add(lab);
				   JButton btnTel = bouton("Ouvrir",400,posFichierE,120,30,null,Color.white);
				   btnTel.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent arg0) {
							File file = new File("C:\\Users\\pcstar\\Desktop\\fichier\\"+nomF);
				              Desktop desktop = Desktop.getDesktop();
				        try {
				            desktop.open(file);
				        } catch (IOException ex) { }
						}});
				   pIHM3.add(btnTel);
				   
				   posFichierE+=50;
			   }
				}
	 }
			
	public void chargerTP() {
		 
		//connexion a la base de donnee	
			Connection connect = null; // connexion avec la base
			PreparedStatement stm=null; // objet d'�mission des requ�tes
			ResultSet resultat = null;

			try{
				//charger le pilote
				 Class.forName("com.mysql.cj.jdbc.Driver");
				 connect=DriverManager.getConnection("jdbc:mysql://localhost:3306/tpihm","root","");
				 stm=connect.prepareStatement("select * from TP;");
				 resultat= stm.executeQuery();

				 while(resultat.next()) {
					 String  y = resultat.getString("nom").toString();
						String z = resultat.getString("nomFichier").toString();
						
						JLabel lab = new JLabel();
						lab.setText(z+" ajout� par " + y);
						lab.setBounds(25, posFichierTP, 325, 30);
						pIHM2.add(lab);
						
						JButton btnTel = bouton("Ouvrir",400,posFichierTP,120,30,null,Color.white);
						btnTel.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent arg0) {
								File file = new File("C:\\Users\\pcstar\\Desktop\\fichier\\"+z);
					              Desktop desktop = Desktop.getDesktop();
					        try {
					            desktop.open(file);
					        } catch (IOException ex) { }
							}});
						pIHM2.add(btnTel);
						
						posFichierTP+=50;
				 }
					} catch (Exception e){System.out.println(e);} 
			
			// fermeture de la base
				finally {
				        if (resultat != null) try { resultat.close(); } catch (SQLException ignore) {}
				        if (stm != null) try { stm.close(); } catch (SQLException ignore) {}
				        if (connect != null) try { connect.close(); } catch (SQLException ignore) {}
				    }
	 }
	
	public void chargerCours() {
		 
		//connexion a la base de donnee	
			Connection connect = null; // connexion avec la base
			PreparedStatement stm=null; // objet d'�mission des requ�tes
			ResultSet resultat = null;
			
			try{
				//charger le pilote
				 Class.forName("com.mysql.cj.jdbc.Driver");
				 connect=DriverManager.getConnection("jdbc:mysql://localhost:3306/tpihm","root","");
				 stm=connect.prepareStatement("select * from Cours;");
				 resultat= stm.executeQuery();
					while(resultat.next()) {
						String y = resultat.getString("nom").toString();
						String z = resultat.getString("nomFichier").toString();
						
						JLabel lab = new JLabel();
						lab.setText(z + " ajout� par " + y);
						lab.setBounds(25, posFichierC, 325, 30);
						pIHM1.add(lab);
						JButton btnTel = bouton("Ouvrir",400,posFichierC,120,30,null,Color.white);
						pIHM1.add(btnTel);
						btnTel.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent arg0) {
								File file = new File("C:\\Users\\pcstar\\Desktop\\fichier\\"+z);
					              Desktop desktop = Desktop.getDesktop();
					        try {
					            desktop.open(file);
					        } catch (IOException ex) { }
							}	
						});
						posFichierC+=50;
				 }
				 } catch (Exception e){System.out.println(e);} 
			
			// fermeture de la base
				finally {
				        if (resultat != null) try { resultat.close(); } catch (SQLException ignore) {}
				        if (stm != null) try { stm.close(); } catch (SQLException ignore) {}
				        if (connect != null) try { connect.close(); } catch (SQLException ignore) {}
				    }
		
	 }

	public void chargerExm() {
		 
		//connexion a la base de donnee	
			Connection connect = null; // connexion avec la base
			PreparedStatement stm=null; // objet d'�mission des requ�tes
			ResultSet resultat = null;
			try{
				
				//charger le pilote
				 Class.forName("com.mysql.cj.jdbc.Driver");
				 connect=DriverManager.getConnection("jdbc:mysql://localhost:3306/tpihm","root","");
				 stm=connect.prepareStatement("select * from examen;");
				 resultat= stm.executeQuery();
					while(resultat.next()) {
						String y = resultat.getString("nom").toString();
						String z = resultat.getString("nomFichier").toString();

						JLabel lab = new JLabel();
						lab.setText(z + " ajout� par " + y);
						lab.setBounds(25, posFichierE, 325, 30);
						pIHM3.add(lab);
						JButton btnTel = bouton("Ouvrir",400,posFichierE,120,30,null,Color.white);
						pIHM3.add(btnTel);
						btnTel.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent arg0) {
								File file = new File("C:\\Users\\pcstar\\Desktop\\fichier\\"+z);
					              Desktop desktop = Desktop.getDesktop();
					        try {
					            desktop.open(file);
					        } catch (IOException ex) { }
							 
							}});
						
						posFichierE+=50;
				 }
				 } catch (Exception e){System.out.println(e);} 
			
			// fermeture de la base
				finally {
				        if (resultat != null) try { resultat.close(); } catch (SQLException ignore) {}
				        if (stm != null) try { stm.close(); } catch (SQLException ignore) {}
				        if (connect != null) try { connect.close(); } catch (SQLException ignore) {}
				    }
		
	 }


	
	public void ajouterComm(String Com){
		DateFormat format = new SimpleDateFormat("yyyy/MM/dd");
		 Calendar calendar = Calendar.getInstance();
		JLabel commlogo = new JLabel(format.format(calendar.getTime()));
	    commlogo.setForeground(new Color(0,18,55));
		commlogo.setBounds(10, posComm-20, 100, 100);
		panComm.add(commlogo);
		
		connexionSQLInsert("insert into commentaire (nom,Comm,date) values ('"+nom+"','"+Com+"','"+format.format(calendar.getTime())+"');");
		 		
		 		JTextArea txtA = new JTextArea(Com);
				txtA.setEditable(false);
				txtA.setForeground(Color.BLACK);
				txtA.setBackground(Color.WHITE);	
				txtA.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.black), nom, 0, 0, new Font("Comic sans MS", Font.BOLD, (int) 15.),Color.black));
				txtA.setFont(new Font("Comic sans MS", 13, 13));
				txtA.setBounds(90,posComm , 470, 60);
				panComm.add(txtA);
				
				posComm+=65;
			   
	 }
	
	public void chargerCmm() {
		 
		//connexion a la base de donnee	
			Connection connect = null; // connexion avec la base
			PreparedStatement stm=null; // objet d'�mission des requ�tes
			ResultSet resultat = null;
			
			try{
				//charger le pilote
				 Class.forName("com.mysql.cj.jdbc.Driver");
				 connect=DriverManager.getConnection("jdbc:mysql://localhost:3306/tpihm","root","");
				 stm=connect.prepareStatement("select * from Commentaire;");
				 resultat= stm.executeQuery();
					while(resultat.next()) {
						String y = resultat.getString("nom").toString();
						String z = resultat.getString("Comm").toString();
						Date date = resultat.getDate("date");
						 
						JLabel commlogo = new JLabel(date.toString());
					    commlogo.setBounds(10, posComm-20, 100, 100);
					    commlogo.setForeground(new Color(0,18,55));
						panComm.add(commlogo);
						
						JTextArea txtA = new JTextArea(z);
						txtA.setEditable(false);
						txtA.setForeground(Color.BLACK);
						txtA.setBackground(Color.WHITE);
						txtA.setFont(new Font("Comic sans MS", 13, 13));	
						txtA.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(new Color(0,18,55)), y, 0, 0, new Font("Comic sans MS", Font.BOLD, 15), new Color(0,18,55)));
						txtA.setBounds(90,posComm , 470, 60);
						panComm.add(txtA);
						posComm+=60;
				 }
				 } catch (Exception e){System.out.println(e);} 
			
			// fermeture de la base
				finally {
				        if (resultat != null) try { resultat.close(); } catch (SQLException ignore) {}
				        if (stm != null) try { stm.close(); } catch (SQLException ignore) {}
				        if (connect != null) try { connect.close(); } catch (SQLException ignore) {}
				    }
	 }
}